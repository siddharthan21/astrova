// var express = require('express');
// var router = express.Router();
// const { MongoClient } = require('mongodb');

// const cr = {
//     email:"ss",
//     pass:"ps"
// }

// router.post('/login',(req,res)=>{
//     if(req.body.email==cr.email && req.body.password == cr.pass){

//         req.session.user = req.body.email
//         // res.redirect('/home')
//         res.send(documents)
//         // res.end(documents)
//     }else{
//         res.end("dff")
//     }
// })

// module.exports = router