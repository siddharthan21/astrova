// const mongoose = require("mongoose")
// const express = require('express');

// const app = express();

// DB_URL = "mongodb://localhost:27017/auth"

// mongoose.connect(DB_URL)
// if(mongoose.connection){
//     console.log("ss")
// }